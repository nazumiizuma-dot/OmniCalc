import math
def sin_deg(x_deg: float): return math.sin(math.radians(x_deg))
def cos_deg(x_deg: float): return math.cos(math.radians(x_deg))
def tan_deg(x_deg: float): return math.tan(math.radians(x_deg))
